QuickStart with minitage
=============================

The whole doc is not there
-----------------------------------
but on http://minitage.github.io

The installation instructions are there:

Automatic installation
------------------------------------------

    See http://minitage.github.io/installation.html

Using virtualenv (deprecated)
--------------------------------------

    See http://minitage.github.io/installation_old.html

Syncing packages
----------------------

    See http://minitage.github.io/usecases/using_minimerge.html#update-your-minilays


Integrate your existing python project base on buildout
--------------------------------------------------------

    See http://minitage.github.io/usecases/maintain_project.html

