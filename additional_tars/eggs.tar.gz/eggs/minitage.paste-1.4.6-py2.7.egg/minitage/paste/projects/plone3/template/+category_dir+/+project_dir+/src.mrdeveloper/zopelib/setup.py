from distutils.core import setup
setup(name='zopelib', version='2.10.7')
