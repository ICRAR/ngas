apt-get install python2.4 python-virtualenv
apt-get install python2.4-dev

apt-get install build-essential wget gcc g++ make tar gzip bzip2 readline-common wv xpdf libxml2 libxslt1
apt-get install libssl-dev zlib1g-dev libreadline5-dev libjpeg62-dev libxml2-dev libxslt1-dev

apt-get install libservlet2.5-java libtomcat6-java tomcat6 tomcat6-common

apt-get install ldap-utils libldap-2.4-2 libnss-ldap
apt-get install libldap2-dev libsasl2-dev libcrypto++-dev libssl-dev

apt-get install mysql-server mysql-client python-mysqldb
apt-get install libmysqlclient15-dev

apt-get install postgresql-8.3 postgresql-client-8.3
apt-get install libpq-dev

apt-get install unzip
