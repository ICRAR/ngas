# GNU General Public License for more details.

__docformat__ = 'restructuredtext en'

# vim:set et sts=4 ts=4 tw=80:
