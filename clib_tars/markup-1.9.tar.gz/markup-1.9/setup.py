from distutils.core import setup 

setup(name='markup',
      version='1.9',
      description='Pythonic HTML/XML generator',
      author='Roel Mathys et al.',
      author_email='nogradi@gmail.com',
      url='http://markup.sourceforge.net/',
      packages=['markup', ],
      package_data={'doc': ['doc/*']},
      data_files=[('doc',['doc/examples.py', 'doc/index.html', 'doc/markup.css']),],
)
