.. ref-elasticache

==================
Amazon ElastiCache
==================

boto.elasticache
----------------

.. automodule:: boto.elasticache
   :members:
   :undoc-members:

boto.elasticache.layer1
-----------------------

.. automodule:: boto.elasticache.layer1
   :members:
   :undoc-members:
