/******************************************************************************
 * E.S.O. - VLT project
 *
 * "@(#) $Id: chksumAddFitsChksum.c,v 1.2 2004/11/05 13:27:08 jknudstr Exp $"
 *
 * Who       When        What
 * --------  ----------  ----------------------------------------------
 * jknudstr  02/11/2004  Created
 */




#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "chksum.h"

/**
Tool that goes through each HDU of a FITS file and checks and adds (if
necessary) the DATASUM and CHECKSUM for each HDU.
 */
int main(int argc, char *argv[])
{
    char       status[128];

    if (argc != 2)
	{
	fprintf(stderr, "\nCorrect usage:\n\n$ %s <FITS file>\n\n", argv[0]);
	exit(1);
	}
    if (chksumAddFitsChksum(argv[1], status) != 0)
	{
	fprintf(stderr, "Error encountered adding datasum/checksum in " 
		"file: %s. Error: %s.",	argv[1], status);
	exit(1);
	}
    printf("Added datasum/checksum in file: %s. Status: OK\n", argv[1]);
    exit(0);
}

/* EOF  */
