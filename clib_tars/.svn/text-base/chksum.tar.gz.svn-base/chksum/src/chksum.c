/****************************************************************************
 * E.S.O. - Archive System
 *
 * "@(#) $Id: chksum.c,v 1.21 2005/11/11 10:55:08 jknudstr Exp $"
 *
 * Who       When        What
 * --------  ----------  ----------------------------------------------
 * jknudstr  20/01/2000  Borrowed from CFTISIO.
 * jknudstr  16/09/2003  Made standalone module for this library.
 */




#include <stdio.h>

#include "fitsio.h"

/**
See chksum/README for more information about this module.
*/

#include "chksum.h"

/**
The function checks the consistency of a file according to the scheme for
DATASUM and CHECKSUM defined by the FITS standard. 

The check is done per HDU.
*/
int chksumVerFitsChksum(const char *fitsFile,
			char       status[64])
{
    int        stat, noOfHdus, hdu, hduType, dataOk, hduOk;
    fitsfile   *fptr;

    fptr = NULL;
    stat = 0;
    if (fits_open_file(&fptr, fitsFile, READONLY, &stat) != 0)
	goto errExit;
    if (fits_get_num_hdus(fptr, &noOfHdus, &stat) != 0)
	goto errExit;
    for (hdu = 1; hdu <= noOfHdus; hdu++)
	{
	if (fits_movabs_hdu(fptr, hdu, &hduType, &stat) != 0)
	    goto errExit;
	if (fits_verify_chksum(fptr, &dataOk, &hduOk, &stat) != 0)
	    goto errExit;
	if (dataOk != 1)
	    {
	    sprintf(status, "Invalid DATASUM for HDU: %d (prim hdr=1)", hdu);
	    break;
	    }
	if (hduOk != 1)
	    {
	    sprintf(status, "Invalid CHECKSUM for HDU: %d (prim hdr=1)", hdu);
	    break;
	    }
	}
    fits_close_file(fptr, &stat);
    
    /* If inconsistencies are found, try to verify the checksum according to
     * the obsolete scheme, based on a global checksum value in the file.
     */
    if ((dataOk != 1) || (hduOk != 1))
	{
	char    status[256];
	if (chksumCheckGlobChecksum(fitsFile, status) != 0) return 1;
	}

    return 0;

 errExit:
    if (fptr) fits_close_file(fptr, &stat);
    if (stat) fits_get_errstatus(stat, status);
    return 1;
}



/**
The function goes through the FITS file and adds Checksum and Datasum for 
each HDU. A global Checksum for the entire file, will be added in the 
Primary Header.
*/
int chksumAddFitsChksum(const char *fitsFile,
			char       status[64])
{
    int        stat, noOfHdus, hdu, hduType;
    fitsfile   *fptr;

    fptr = NULL;
    stat = 0;
    if (fits_open_file(&fptr, fitsFile, READWRITE, &stat) != 0)
	goto errExit;
    if (fits_get_num_hdus(fptr, &noOfHdus, &stat) != 0)
	goto errExit;
    for (hdu = 1; hdu <= noOfHdus; hdu++)
	{
	if (fits_movabs_hdu(fptr, hdu, &hduType, &stat) != 0)
	    goto errExit;
	if (fits_write_chksum(fptr, &stat) != 0)
	    goto errExit;
	}
    if (fits_movabs_hdu(fptr, 1, &hduType, &stat) != 0)
	goto errExit;
    fits_close_file(fptr, &stat);

    return 0;

 errExit:
    if (fptr) fits_close_file(fptr, &stat);
    if (stat) fits_get_errstatus(stat, status);
    return 1;
}


/**
Probe if the architecture is Little-endian or Big-endian and return the result
(chksumLITTLE_ENDIAN, chksumBIG_ENDIAN).
*/
int chksumDetectArchitecture()
{
    /* Initialize first member of p with unsigned 1 */
    chksumProbe p = { 1U }; 
    /* In a big endian architecture, p.bytes[0] equals 0 */
    if (p.bytes[0] == 1U)
	return chksumLITTLE_ENDIAN;
    else
	return chksumBIG_ENDIAN;
}


/**
Function used to check the global checksum for a FITS file.
*/
int chksumCheckGlobChecksum(const char  *filename,
			    char        status[256])
{
    fitsfile *fptr;
    int stat = 0;
    unsigned long checksum, datsum;
    
    if (ffopen(&fptr, filename, READONLY, &stat) > 0)
	{
	sprintf(status, "%s [ERROR] open %d\n", filename, stat);
	return 1;
	}
    ffgcks(fptr, &datsum, &checksum, &stat);
    if (stat != 0)
	{
        sprintf(status, "%s [ERROR] validating checksum %d\n", filename, stat);
	return 1;
	}
    else if (~checksum != 0)
	{
	sprintf(status, "%s [ERROR] validating checksum %lu\n", filename, 
		~checksum);
	return 1;
	}
    if (ffclos(fptr, &stat) > 0)
	{
        sprintf(status, "ffclos status = %d\n\n", stat);
	return 1;
	}
    sprintf(status, "Status: OK");
    return 0;
}


/* EOF */
