/******************************************************************************
 * E.S.O. - VLT project
 *
 * "@(#) $Id: chksumVerFitsChksum.c,v 1.4 2005/11/11 09:38:45 jknudstr Exp $"
 *
 * Who       When        What
 * --------  ----------  ----------------------------------------------
 * jknudstr  02/11/2004  Created
 */




#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "chksum.h"

/**
Tool that checks each HDU of a FITS file and thereby validates the DATASUM
and CHECKSUM for that HDU.
 */
int main(int argc, char *argv[])
{
    char       status[128];

    if (argc != 2)
	{
	fprintf(stderr, "\nCorrect usage:\n\n$ %s <FITS file>\n\n", argv[0]);
	exit(1);
	}
    if (chksumVerFitsChksum(argv[1], status) != 0)
	{
	fprintf(stderr, "Status: NOT OK");
	exit(1);
	}
    printf("Status: OK");
    exit(0);
}

/* EOF  */
