/******************************************************************************
 * E.S.O. - VLT project
 *
 * "@(#) $Id: chksumGenChecksum.c,v 1.5 2006/02/21 10:48:20 jknudstr Exp $"
 *
 * Who       When        What
 * --------  ----------  ----------------------------------------------
 * jknudstr  09/06/2001  Created
 * jknudstr  16/09/2003  Made standalone module for this.
 */




#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "chksum.h"

#define CHUNK (10 * 2880)

/* NOTE: THIS UTILITY IS KEPT FOR BACKWARDS COMPATIBILITY REASONS. */

/* 
  Swap the bytes in the input short integers: ( 0 1 -> 1 0 ).
 */
void chksumFfswap(short *svalues,  /* Pointer to shorts to be swapped   */
		  long nvals)      /* Number of shorts to be swapped    */
{
    register char *cvalues;
    register long ii;

    union u_tag {
        char cvals[2];   /* equivalence an array of 4 bytes with */
        short sval;      /* a short */
    } u;
    
    cvalues = (char *) svalues;      /* copy the initial pointer value */
    
    for (ii = 0; ii < nvals;)
	{
        u.sval = svalues[ii++];  /* copy next short to temporary buffer */
	
        *cvalues++ = u.cvals[1]; /* copy the 2 bytes to output in turn */
        *cvalues++ = u.cvals[0];
	}
    return;
}

/*
  Encode the 32 bit checksum by converting every 
  2 bits of each byte into an ASCII character (32 bit word encoded 
  as 16 character string).   Only ASCII letters and digits are used
  to encode the values (no ASCII punctuation characters).
  
  If complm=TRUE, then the complement of the sum will be encoded.
  
  This routine is based on the C algorithm developed by Rob
  Seaman at NOAO that was presented at the 1994 ADASS conference,
  published in the Astronomical Society of the Pacific Conference Series.
*/
void chksumFfesum(unsigned long sum,    /* accumulated checksum              */
		  int           complm, /* 1 to encode complement of the sum */
		  char          *ascii) /* 16-char ASCII encoded checksum    */
{
    unsigned int exclude[13] = { 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f, 0x40,
				 0x5b, 0x5c, 0x5d, 0x5e, 0x5f, 0x60 };
    unsigned long mask[4] = { 0xff000000, 0xff0000, 0xff00, 0xff  };
    
    int offset = 0x30;     /* ASCII 0 (zero) */
    
    unsigned long value;
    int byte, quotient, remainder, ch[4], check, ii, jj, kk;
    char asc[32];
    
    if (complm)
        value = 0xFFFFFFFF - sum;   /* complement each bit of the value */
    else
        value = sum;
    
    for (ii = 0; ii < 4; ii++)
	{
        byte = (value & mask[ii]) >> (24 - (8 * ii));
        quotient = byte / 4 + offset;
        remainder = byte % 4;
        for (jj = 0; jj < 4; jj++)
            ch[jj] = quotient;
	
        ch[0] += remainder;
	
        for (check = 1; check;)   /* avoid ASCII  punctuation */
            for (check = 0, kk = 0; kk < 13; kk++)
                for (jj = 0; jj < 4; jj += 2)
                    if ((unsigned char) ch[jj] == exclude[kk] ||
                        (unsigned char) ch[jj+1] == exclude[kk])
			{
                        ch[jj]++;
                        ch[jj+1]--;
                        check++;
			}
	
        for (jj = 0; jj < 4; jj++)        /* assign the bytes */
            asc[4*jj+ii] = ch[jj];
	}
    
    for (ii = 0; ii < 16; ii++)       /* shift the bytes 1 to the right */
        ascii[ii] = asc[(ii+15)%16];
    
    ascii[16] = '\0';
}

/*
  Calculate a 32-bit 1's complement checksum of the buffer.
  This routine is based on the C algorithm developed by Rob
  Seaman at NOAO that was presented at the 1994 ADASS conference,  
  published in the Astronomical Society of the Pacific Conference Series.
  This uses a 32-bit 1's complement checksum in which the overflow bits
  are permuted back into the sum and therefore all bit positions are
  sampled evenly. 
*/
void chksumFfcsum(char          *buf,
		  long          bufLen,
		  unsigned long *sum)
{
    long            len, remain, i;
    unsigned short  *sbuf;
    unsigned long   hi, lo, hicarry, locarry;

    sbuf = (unsigned short *)buf;

    len = (2 * (bufLen / 4));
    remain = (bufLen % 4);

#ifdef __linux__
    chksumFfswap((short *)sbuf, len);
#endif
    
    hi = (*sum >> 16);
    lo = *sum & 0xFFFF;

    for (i = 0; i < len; i += 2)
	{
	hi += sbuf[i];
	lo += sbuf[i + 1];
	}

    if (remain >= 1)
	{
	hi += (buf[2 * len] * 0x100);
	if (remain >= 2)
	    {
	    hi += buf[2 * len + 1];
	    if (remain >= 3)
		lo += (buf[2 * len + 2] * 0x100);
	    }
	}
    
    hicarry = hi >> 16;    /* fold carry bits in */
    locarry = lo >> 16;
	
    while (hicarry | locarry)
	{
	hi = (hi & 0xFFFF) + locarry;
	lo = (lo & 0xFFFF) + hicarry;
	hicarry = hi >> 16;
	locarry = lo >> 16;
	}
      
    *sum = (hi << 16) + lo;
}


int main(int argc, char *argv[])
{
    char                checkSum[32];
    char                buf[CHUNK];
    FILE                *filePtr;
    int                 len; 
    unsigned long       sum = 0;

    if (argc != 2)
	{
	fprintf(stderr, "\nCorrect usage:\n\n%% %s "
		"<FITS file>\n\n", argv[0]);
	exit(1);
	}

    if ((filePtr = fopen(argv[1], "r")) == NULL)
	{
	fprintf(stderr, "\n\nCouldn't open file: %s.\n\n", argv[1]);
	exit(1);
	}

    /* 
       Loop over the file and calculate the checksum on the chunks. 
     */
    do
	{
	len = fread(buf, 1, CHUNK, filePtr);
	if (len > 0) chksumFfcsum(buf, len, &sum);
	}
    while (len > 0);
    fclose(filePtr);

    chksumFfesum(sum, 1, checkSum);
    printf("%ld/%s", ~sum, checkSum);

    exit(0);
}

/* --- oOo ---  */







