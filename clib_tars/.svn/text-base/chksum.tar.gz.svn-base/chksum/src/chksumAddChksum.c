/******************************************************************************
 * E.S.O. - VLT project
 *
 * "@(#) $Id: chksumAddChksum.c,v 1.1 2004/11/05 13:27:08 jknudstr Exp $"
 *
 * Who       When        What
 * --------  ----------  ----------------------------------------------
 * jknudstr  05/11/2004  Created from source code from SZA (add_chksum.c)
 */




#include <string.h>
#include <stdio.h>

#include "fitsio.h"


/**
Tool that adds a global CHECKSUM in the Primary Header of the FITS file
referenced. 

NOTE, THIS IS NOT THE CORRECT WAY ACCORDING TO THE FITS STANDARD WHERE A
DATASUM AND A CHECKSUM SHOULD BE ADDED PER HDU IN THE FILE. THIS IS, 
HOWEVER, THE WAY WHICH IT WAS DONE UNTIL NOW (2004-11-05) FOR DATA PRODUCED
AT ESO. WHETHER OR NOT THIS WILL CHANGE IN THE FUTURE, IS NOT YET CLEAR.
*/
int main(int argc, char *argv[])
{
    int      status = 0;  /* CFITSIO status MUST be initialized to zero! */
    int      iomode;
    fitsfile *fptr;       /* FITS file pointer, defined in fitsio.h */
  
    if (argc != 2) 
	{
	fprintf(stderr, "\nCorrect usage:\n\n$ %s <FITS file>\n\n", argv[0]);
	exit(1);
	}
    
    iomode = 1;
    if (!fits_open_file(&fptr, argv[1], iomode, &status)) 
	{
	ffpcks(fptr,&status);
	fits_close_file(fptr, &status);
	}    /* open_file */
  
    /* if error occured, print out error message */
    if (status) fits_report_error(stderr, status);
    exit(status);
}

/* EOF */

