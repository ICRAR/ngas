/******************************************************************************
 * E.S.O. - VLT project
 *
 * "@(#) $Id: chksumDatasum.c,v 1.1 2005/12/05 13:44:29 jknudstr Exp $"
 *
 * Who       When        What
 * --------  ----------  ----------------------------------------------
 * szampier  02/12/2005  Created
 * jknudstr  05/12/2005  Added to chksum module
 */




#include <string.h>
#include <stdio.h>
#include "fitsio.h"


int main(int argc, char *argv[])
{
    fitsfile *fptr; 
    int status = 0, hdupos;
    unsigned long checksum, datsum;
    
    if (argc != 2) 
	{
	printf("Usage:  datasum filename \n");
	return(0);
	}
    
    if (!fits_open_file(&fptr, argv[1], READONLY, &status))
	{
	fits_get_hdu_num(fptr, &hdupos);  /* Get the current HDU position */
	for (; !status; hdupos++)  /* Main loop through each extension */
	    {
	    fits_get_chksum(fptr, &datsum, &checksum, &status);
	    printf("hdu %d datasum %lu status %d\n", hdupos, datsum, status);
	    /* Try to move to next HDU */
	    fits_movrel_hdu(fptr, 1, NULL, &status);  
	    }
	if (status == END_OF_FILE)  status = 0; /* Reset after normal error */
	fits_close_file(fptr, &status);
	}

    /* Print any error message */
    if (status) fits_report_error(stderr, status); 
    return(status);
}

/* EOF */

