/******************************************************************************
 * E.S.O. - VLT project
 *
 * "@(#) $Id: chksumCheckFile.c,v 1.1 2004/11/05 13:27:08 jknudstr Exp $"
 *
 * Who       When        What
 * --------  ----------  ----------------------------------------------
 * jknudstr  09/06/2001  Created
 * jknudstr  16/09/2003  Made standalone module for this.
 */





#include <string.h>
#include <stdlib.h>

#include "fitsio.h"

#define MAXPATHLEN 1024

/**
Tool that checksthe CHECKSUM/DATASUM in the Primary Header of the FITS file
referenced. 

NOTE, THIS IS NOT THE CORRECT WAY ACCORDING TO THE FITS STANDARD WHERE A
DATASUM AND A CHECKSUM SHOULD BE ADDED PER HDU IN THE FILE. THIS IS, 
HOWEVER, THE WAY WHICH IT WAS DONE UNTIL NOW (2004-11-05) FOR DATA PRODUCED
AT ESO. WHETHER OR NOT THIS WILL CHANGE IN THE FUTURE, IS NOT YET CLEAR.
*/
int main(int argc, char **argv)
{
    char pathname[MAXPATHLEN];
    fitsfile *fptr;
    int status = 0;
    unsigned long checksum, datsum;

    if (argc != 2)
	{
	fprintf(stderr, "\nCorrect usage:\n\n$ %s <FITS file>\n\n", argv[0]);
	exit(1);
	}
    
    strcpy(pathname, argv[1]);
    if (ffopen(&fptr, pathname, READONLY, &status) > 0 )
	{
        printf("%s [ERROR] open %d\n",pathname,status);
        perror("error");
        exit (2);
	}
    
    ffgcks(fptr, &datsum, &checksum, &status);
    if (status != 0)
        printf("%s [ERROR] validating checksum %d\n", pathname, status);
    else if ((~checksum != 0) || (datsum != 0))
	printf("%s [ERROR] validating checksum %lu %lu\n", pathname, 
	       ~checksum, datsum);
    else
        printf("%s [OK] %lu %lu\n", pathname, ~checksum, datsum);

    if (ffclos(fptr, &status) > 0)
	{
        printf("ffclos status = %d\n\n", status);
        exit (1);
	}
    exit(0);
}

/* EOF  */
