#ifndef chksum_H
#define chksum_H
/******************************************************************************
* E.S.O. - VLT project
#
# "@(#) $Id: chksum.h,v 1.8 2005/11/11 09:38:45 jknudstr Exp $" 
*
* who       when      what
* --------  --------  ----------------------------------------------
* jknudstr  09/06/01  Created
* jknudstr  16/09/03  Made stand-alone module for this.
*/

#ifdef __cplusplus
extern "C" {
#endif

#define chksumLITTLE_ENDIAN  1
#define chksumBIG_ENDIAN     2

typedef union chksumProbe_
{
    unsigned int  num;
    unsigned char bytes[sizeof(unsigned int)];
} chksumProbe;

int chksumVerFitsChksum(const char *fitsFile,
			char       status[128]);

int chksumAddFitsChksum(const char *fitsFile,
			char       status[128]);

int chksumDetectArchitecture();

int chksumCheckGlobChecksum(const char  *filename,
			    char         status[256]);

#ifdef __cplusplus
}
#endif

#endif /*!chksum_H*/









